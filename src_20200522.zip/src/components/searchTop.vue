<template>
  <div class="searchTop">
    <div class="header-top">
      <div class="reposbox">
        <p class="text">
          欢迎来到科研软件汇聚平台！
        </p>

        <div v-if="!userId">
          <a class="right-text" target="_blank" href="https://passport.escience.cn/regist.jsp">注册 </a>
          <a class="right-text" :href="toLoginUrl">登录 &nbsp;&nbsp;&nbsp;|</a>
          {{userId}}
        </div>
        <div v-else="">
          <a class="right-text" @click="signOut" href="https://passport.escience.cn/logout?WebServerURL=http://www.scihub.cstcloud.cn">退 &nbsp;出 </a>
          <p @click="toPersonalInfo" class="right-text">{{userInfo.trueName}},&nbsp;&nbsp;个人中心&nbsp;&nbsp;&nbsp;|</p>
        </div>

      </div>
    </div>
    <div class="searchtop-box">
      <div class="con">
        <router-link to="/">
          <img class="logo" src="../assets/img/search_logo.png" alt="logo" />
        </router-link>
        <div class="search-box">
          <el-select class="classify" v-model="searchArr.itemType" @change="searchTYpe" placeholder="请选择">
            <el-option v-for="item in searchOptions" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <div class="input">
            <el-input @keyup.enter.native="toSearchList" v-model.trim="searchArr.keyword" auto-complete="off"></el-input>
          </div>
          <!-- <router-link  :to="{path:'/searchList',query:searchArr}"> -->
          <button @click="toSearchList"><i class="el-icon-search"></i></button>
          <!-- </router-link> -->
        </div>
        <div @click="deliverySoft" class="btn">
          <span class="el-icon-circle-plus-outline"></span>
          <p>投递软件</p>
        </div>
        <div class="hot-keyword">

          <span v-for="(item,index) in hotKeyWordList" :key="index" :class="index%2==0?'color-blur':''" @click="()=>{changeHotWord(item.keyword)}">{{item.keyword}}</span>
        </div>
     <!--   <button class="btn-submit">
          投递软件
        </button>-->
      </div>
      <div class="menu-box">
        <div class="classify-btn">
          <i class="el-icon-menu"></i>
          <p>全部分类</p>
          <ul  class="classify-first">
            <li v-for="(item, index) in softTypeList" :key="index">
              <router-link :to="{path:'/list',query:{categoryId:item.value,categoryName:item.label,type:1,ParentName:'首页'}}">
              <img src="../assets/icon/icon_classfiy.png" alt="">
              <span>{{item.label}}</span>
              </router-link>
              <div class="classify-second">
                <dl  v-for="(i, k) in item.children" :key="k" :style="{width:(i.children.length>0?'100%':'auto'),float:(i.children.length>0?'none':'left')}">
                  <dt><router-link :to="{path:'/list',query:{categoryId:i.value,categoryName:i.label,type:2,ParentName:'首页'}}">{{i.label}}</router-link></dt>
                  <dd><span   v-for="(todo, j) in i.children" :key="j"><router-link :to="{path:'/list',query:{categoryId:todo.value,categoryName:todo.label,type:3,ParentName:'首页'}}">{{todo.label}} |</router-link></span></dd>
                </dl>
              </div>
            </li>
            <!--  <li>
                <img src="../assets/icon/icon_shoufei.png" alt="">
                <span>收费方式</span>
              </li>
              <li>
                <img src="../assets/icon/icon_lingyu.png" alt="">
                <span>科学领域</span>
              </li>
              <li>
                <img src="../assets/icon/icon_code.png" alt="">
                <span>开发领域</span>
              </li>
              <li>
                <img src="../assets/icon/icon_langage.png" alt="">
                <span>编程语言</span>
              </li>-->
          </ul>
        </div>
        <ul class="menu-list">
          <li  v-for="(item, index) in navList" :key="index" :class="menuId==item.value?'active':''">
            <router-link :to="{path:'/list',query:{categoryId:item.value,categoryName:item.label,type:2,ParentName:'首页'}}">
              {{item.label}}
            </router-link>
          </li>
        </ul>
      </div>
    </div>
    <el-dialog custom-class="examinedialog " :close-on-click-modal="false" :close-on-press-escape="false" title="投递软件" :visible.sync="dialogDelivering">
      <el-form :model="form" ref="form" :rules="rules" :inline="true" class="demo-form-inline" @submit.native.prevent>
        <div class="box-big1">
          <el-form-item prop="name" label="软件名称" :label-width="formLabelWidth">
            <el-input v-model="form.name" placeholder="请输入软件名称" auto-complete="off"></el-input>
          </el-form-item>
        </div>
        <div class="box-small">
          <el-form-item prop="softVersion" label="软件版本" :label-width="formLabelWidth">
            <el-input v-model="form.softVersion" placeholder="请输入软件版本" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item prop="opensourceType" label="软件类型" :label-width="formLabelWidth">
           <!-- <el-select v-model="form.opensourceType" value-key="id" filterable multiple placeholder="请选择开源类型">
              <el-option v-for="item in opensourceTypeOption" :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.opensourceType"
              :options="opensourceTypeOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>
          </el-form-item>

          <el-form-item prop="softCategory" label="收费方式" :label-width="formLabelWidth">
        <!--    <el-select v-model="form.softCategory" value-key="id" filterable multiple placeholder="请选择软件类别">
              <el-option v-for="item in softCategoryOption " :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.softCategory"
              :options="softCategoryOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>

          </el-form-item>
          <el-form-item prop="Language" label="编程语言" :label-width="formLabelWidth">
            <!--<el-select v-model="form.Language" value-key="id" filterable multiple placeholder="请选择编程语言">
              <el-option v-for="item in LanguageOption " :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.Language"
              :options="LanguageOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>
          </el-form-item>
        </div>
        <div class="box-small">
          <el-form-item prop="userInterface" label="学科领域" :label-width="formLabelWidth">
            <!--<el-select v-model="form.userInterface" value-key="id" filterable multiple placeholder="请选择用户接口">
              <el-option v-for="item in userInterfaceOption " :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.userInterface"
              :options="userInterfaceOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>
          </el-form-item>
          <el-form-item prop="applicationField" label="开发领域" :label-width="formLabelWidth">
            <!--<el-select v-model="form.applicationField" value-key="id" filterable multiple placeholder="请选择应用领域">
              <el-option v-for="item in applicationFieldOption " :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.applicationField"
              :options="applicationFieldOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>
          </el-form-item>
          <el-form-item prop="openType" label="开源类型" :label-width="formLabelWidth">
            <!--<el-select v-model="form.applicationField" value-key="id" filterable multiple placeholder="请选择应用领域">
              <el-option v-for="item in applicationFieldOption " :key="item.id" :label="item.ctyName" :value="item">
              </el-option>
            </el-select>-->
            <el-cascader
              v-model="form.openType"
              :options="openTypeOption"
              :props="{ multiple: true, checkStrictly: true }"
              clearable></el-cascader>
          </el-form-item>

        </div>
        <div class="box-big1">
          <el-form-item prop="operatingSystem" label="操作平台" :label-width="formLabelWidth">
            <el-select v-model="form.operatingSystem" value-key="id" filterable multiple placeholder="请选择操作平台">
              <el-option v-for="item in operatingSystemOption " :key="item.id" :label="item.label" :value="item">
              </el-option>
            </el-select>

          </el-form-item>
        </div>

        <div class="box-big1">

          <el-form-item prop="softUrl" label="代码地址" :label-width="formLabelWidth">
            <el-input v-model="form.softUrl" @blur='checkUrl' placeholder="github或cstos.cstcloud.cn的项目地址，推荐使用cstos.cstcloud.cn" auto-complete="off"></el-input>
            <p class="diatit">多个地址请用英文","分隔</p>
          </el-form-item>

        </div>

        <div class="box-big1">
          <el-form-item prop="jumpUrl" label="跳转地址" :label-width="formLabelWidth">
            <el-input v-model="form.jumpUrl" placeholder="请输入跳转地址" auto-complete="off"></el-input>
          </el-form-item>
        </div>
        <div class="box-big1">
          <el-form-item prop="isRun" label="是否立即运行" :label-width="formLabelWidth">
            <el-radio v-model="form.isRun" label= '0'>否</el-radio>
            <el-radio v-model="form.isRun" label= '1'>是</el-radio>
          </el-form-item>
        </div>
        <div class="box-big1" >
          <el-form-item prop="runUrl" label="立即运行路径" :label-width="formLabelWidth" v-if="this.form.isRun === '1'">
            <el-input v-model="form.runUrl" placeholder="请输入立即运行路径" auto-complete="off"></el-input>
          </el-form-item>
        </div>

        <div class="box-big1">
          <el-form-item v-if="!form.ifSelfStudy" label="开发人员" :label-width="formLabelWidth">
            <el-input v-model="form.developer" placeholder="请输入内容开发人员" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label=" " :label-width="formLabelWidth">
            <el-checkbox style="width: 100%;" v-model="form.ifSelfStudy">是否为自研</el-checkbox>
          </el-form-item>
        </div>

        <div v-if="form.ifSelfStudy">
          <h3 class="h3">开发人员</h3>
          <table class="singtext" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th width="20">&nbsp;</th>
              <th width="100">姓名</th>
              <th width="110">所在单位</th>
              <th width="110">软件中承担工作</th>
              <th width="160">手机</th>
              <th width="60">操作</th>
            </tr>
            <tr>
              <td class="domainsnum"><span>*</span></td>
              <td>
                <el-input v-model="firstDomains.userName" auto-complete="off"></el-input>
                <!-- <p class="textp">{{nameValueTit}}</p>-->
              </td>
              <td>
                <el-input v-model="firstDomains.userUnit" auto-complete="off"></el-input>
                <!-- <p class="textp"> {{companyValueTit}}</p>-->

              </td>
              <td>
                <el-input v-model="firstDomains.userJob" auto-complete="off"></el-input>
                <!--  <p class="textp">{{roleValueTit}}</p>-->
              </td>
              <td>
                <el-input v-model="firstDomains.userPhone" auto-complete="off"></el-input>
                <!--  <p class="textp">{{phoneValueTit}}</p>-->
              </td>
              <td>&nbsp;</td>
            </tr>
            <tr v-for="(item, index) in secondDomains" :key="index">
              <td class="domainsnum"><span>*</span></td>
              <td>
                <el-input v-model="item.userName" auto-complete="off"></el-input>
              </td>
              <td>
                <el-input v-model="item.userUnit" auto-complete="off"></el-input>

              </td>
              <td>
                <el-input v-model="item.userJob" auto-complete="off"></el-input>

              </td>
              <td>
                <el-input v-model="item.userPhone" auto-complete="off"></el-input>
<!--                <p class="textp">{{phoneValueTit}}</p>-->

              </td>
              <td>
<!--                <div @click="delTr($event)" class="deltrbtn">删除</div>-->
                <div @click="delTr(index)"  class="deltrbtn">删除</div>
              </td>
            </tr>

            <tr>
              <td colspan="6">
                <a href="javascript:;" @click="addDomain" class="addtr">新增一行</a>
                <el-checkbox style="float: right; margin:10px 10px 0 0 ;color: #999;" v-model="form.ifHsowRealName">是否匿名</el-checkbox>
              </td>
            </tr>
          </table>
        </div>
        <el-form-item prop="abstract" label="作品摘要" :label-width="formLabelWidth">
          <div class="box-input">
            <tinymce-editor v-model="form.abstract" :disabled=false ref="editor"></tinymce-editor>
          </div>
        </el-form-item>

        <div class="bottom">
          <div class="left-box">
            <el-form-item label=" " :label-width="formLabelWidth">
              <el-checkbox v-model="ifCheckedMzs">
                <router-link target="_blank" to="page3">软件投递免责协议</router-link>
              </el-checkbox>

            </el-form-item>

          </div>

          <div class="right">
            <el-button @click="closePop">取 消</el-button>
            <el-button type="primary" @click="submitForm('form')">确 定</el-button>
          </div>

        </div>
      </el-form>

    </el-dialog>

    <!--pop-->
    <!--pop-->
  </div>
</template>

<script>
  import TinymceEditor from '@/components/tinymce-editor'
  import baseUrl from "../../config";
  export default {
    name: 'searchTop',
    components: {
      TinymceEditor
    },
    props: {
      newSoftUrl: '',
      runUrl: ''
    },

    data() {
      return {
        showLogin:false,
        softTypeList:[],//分类
        navList:[],//菜单分类
        userId: "",
        dialogDelivering:false,
        baseUrl:window.SITE_CONFIG['apiURL'],
        searchArr: {
          keyword: '',
          itemType: 1,
          page: 1,
        },
        searchOptions: [{
          value: 1,
          label: '软件'
        },
          {
            value: 2,
            label: '领域'
          },
          {
            value: 3,
            label: '作者'
          }
        ],
        form: {
          domains: [],
          name: '',
          softVersion: '',
          opensourceType: [],
          applicationField: [],
          openType: [],
          softCategory: [],
          Language: [],
          userInterface: [],
          softUrl: '',
          jumpUrl: '',
          isRun: '0',
          runUrl: '',
          abstract: '',
          developer: '',
          operatingSystem: [],
          ifShowRealName: false,
          ifSelfStudy: false, //是否为自研
          ifHsowRealName: false
        },
        rules: {
          name: [{
            required: true,
            message: '请填写软件名称',
            trigger: 'blur'
          }],
          developer: [{
            required: true,
            message: '请填写开发人员',
            trigger: 'blur'
          }],
          softVersion: [{
            required: true,
            message: '请填写版本号',
            trigger: 'blur'
          }],
          opensourceType: [{
            required: true,
            message: '请填写软件类型',
            trigger: 'blur'
          }],
          applicationField: [{
            required: true,
            message: '请填写开发领域',
            trigger: 'blur'
          }],
          // openType: [{
          //   required: true,
          //   message: '请填写开源类型',
          //   trigger: 'blur'
          // }],
          softCategory: [{
            required: true,
            message: '请选择收费方式',
            trigger: 'blur'
          }],
          Language: [{
            required: true,
            message: '请选择开发语言',
            trigger: 'blur'
          }],
          userInterface: [{
            required: true,
            message: '请填写学科领域',
            trigger: 'blur'
          }],
          // softUrl: [{
          //   required: true,
          //   message: '请填写代码地址',
          //   trigger: 'blur'
          // }],
          abstract: [{
            required: true,
            message: '请填写作品摘要',
            trigger: 'blur'
          }],
          operatingSystem: [{
            required: true,
            message: '请选择操作凭条',
            trigger: 'blur'
          }],

        },
        toLoginUrl: '',
        categoryOption: [],
        formLabelWidth: '120px',
        stepImgSrc: '',
        opensourceTypeOption: [],
        applicationFieldOption: [],
        openTypeOption: [],
        softCategoryOption: [],
        LanguageOption: [],
        userInterfaceOption: [],
        operatingSystemOption: [],
        ifCheckedMzs: false,
        firstDomains: {
          "activityId": 0,
          "awardLevel": 0,
          "awardTime": "",
          "id": 0,
          "joinTime": "",
          "rank": 0,
          "status": 0,
          "userId": 0,
          "userJob": "",
          "userName": "",
          "userPhone": "",
          "userUnit": ""
        },
        secondDomains: [],
        DownWordUrl: '',
        ifDownWordUrl: '',
        feedbackOption: [], //反馈选项
        menuId:1,
        hotKeyWordList:[]
      }
    },
    created(){
      var _this=this;
      $.getScript("http://passport.escience.cn/js/isLogin.do", function(){
        _this.userId= data.result?this.userId:null
        _this.userId= window.SITE_CONFIG['userId']
        console.log("this.userId",_this.userId)
        console.log("data.result",data.result)
      })
    },
    mounted() {
      this.toLoginUrl = window.SITE_CONFIG['apiURL'] + '/haoweb/web/auth/login'
      console.log('this.toLoginUrl', this.toLoginUrl)
      this.menuId=this.$route.query.categoryId
      //获取软件分类
      this.searchArr.keyword=this.$route.query.keyword?this.$route.query.keyword:''
      this.$http.post('/haoweb/web/soft/softCtyAllList',"")
        .then(({data:res })=>{
          this.softTypeList=res.list
          this.navList=this.softTypeList[0].children
        })
      this.getListOption()
      this.getoSystemOption()
      this.getoHotKeyWords()
    },
    watch: {
      '$route'(to, from) {
        this.menuId=this.$route.query.categoryId
      }
    },
    methods: {
      toSearchList() {
        if(this.searchArr.itemType == '软件') {
          this.searchArr.itemType = 1
        }
        if(this.searchArr.itemType == '领域') {
          this.searchArr.itemType = 2
        }
        if(this.searchArr.itemType == '作者') {
          this.searchArr.itemType = 3
        }
        this.$router.push({
          path: '/searchList',
          query: this.searchArr
        });
        this.$emit('serachList', true)
      },
      /*新增*/
      addDomain(){
        this.secondDomains.splice(this.secondDomains.length, 1, {
          "activityId": 0,
          "awardLevel": 0,
          "awardTime": "",
          "id": 0,
          "joinTime": "",
          "rank": 0,
          "status": 0,
          "userId": this.userId,
          "userJob": "",
          "userName": "",
          "userPhone": "",
          "userUnit": ""
        });
      },
      delTr(index){
        this.secondDomains.splice(index, 1);
      },
      /*新增*/
      searchTYpe(){
        if(this.searchArr.itemType == '软件') {
          this.searchArr.itemType = 1
        }
        if(this.searchArr.itemType == '领域') {
          this.searchArr.itemType = 2
        }
        if(this.searchArr.itemType == '作者') {
          this.searchArr.itemType = 3
        }
        console.log("this.searchArr.itemType",this.searchArr.itemType)
        this.getoHotKeyWords()
      },
      toPersonalInfo: function() {
        var _this = this
        _this.$router.push({
          path: '/personalInfo'
        });
      },
      signOut: function() {
        sessionStorage.clear()
      },
      //投递软件
      deliverySoft: function() {
        var _this = this;
        if(!this.userId) {
          _this.$confirm('请登录', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            var newUrl =window.SITE_CONFIG['apiURL'] + '/haoweb/web/auth/login'
            window.open(newUrl)

          }).catch(() => {
          });
        } else {
          _this.dialogDelivering = true;
        }
      },
      //验证git地址是否存在
      checkUrl: function() {
        var _this = this;
        var regexp = /((http|ftp|https|file):\/\/([\w\-]+\.)+[\w\-]+(\/[\w\u4e00-\u9fa5\-\.\/?\@\%\!\&=\+\~\:\#\;\,]*)?)/ig;
        if(_this.form.softUrl) {
          var thisurl = _this.form.softUrl.match(regexp);
          if(!thisurl) {
            _this.messageOpen('填写正确链接地址', 'warning')
            return false
          }
          var params = new URLSearchParams();
          params.append("softUrl", _this.form.softUrl);
          _this.$http.post( '/haoweb/web/soft/checkIsEqualsSoftUrl', params)
            .then(()=>{
              if(response.data.code != 0) {
                _this.$alert(response.data.msg, '提示信息', {
                  confirmButtonText: '确定',
                });
                _this.form.softUrl = ''
              }
            })
            .catch(function(error) {
              console.log(error);
            })
        }
      },
      //开源类型
      submitForm: function(formName) {
        var _this = this;
        var sofoVo = {
          applicationField: "",
          openType: "",
          categoryIds: this.form.applicationField,
          opensourceTypes: this.form.openType,
          createTime: "",
          createUser: this.userId,
          expertEvaluateRejectReason: "",
          firstAudit: 0,
          firstAuditRejectReason: "",
          id: 0,
          createUserName:this.userInfo.trueName,
          isChina: 0,
          isEvaluate: 0,
          isExpertEvaluate: 0,
          isHot: 0,
          isPlatform: 0,
          isRecommend: 0,
          isShow: 0,
          isSelf: '',
          isShowDeveloperName: '',
          developers: this.form.developer,
          opensourceType: "",
          softTypes: this.form.opensourceType,
          operatingSystemList: this.form.operatingSystem,
          operatingSystem: "",
          programmingLanguage: "",
          programmingLanguages: this.form.Language,
          softCategoryId: '',
          softCategoryName: "",
          softId: "",
          softIntroduce: this.form.abstract,
          softLicense: "",
          softLogo: "",
          softName: this.form.name,
          chargingMethods: this.form.softCategory,
          softUrl: this.form.softUrl,
          jumpUrl: this.form.jumpUrl,
          isRun: this.form.isRun,
          runUrl: this.form.runUrl,
          softVersion: this.form.softVersion,
          updateTime: "",
          userInterface: "",
          isMatchSoft: 0,
          applicationFields: this.form.userInterface,
          userList: [],
        }
        sofoVo.isShowDeveloperName = _this.form.ifHsowRealName == true ? 0 : 1;
        sofoVo.isSelf = _this.form.ifSelfStudy == true ? 1 : 0;
        if(!sofoVo.isShowDeveloperName) {
          sofoVo.developers = ''
        }
        /*	var reg = /github.com(.*?)/g;
       var reg1 = /cstos.cstcloud.cn(.*?)/g;
       if(!reg.test(_this.form.softUrl)&&!reg1.test(_this.form.softUrl)){
           _this.messageOpen('代码地址格式不正确,请使用github或cstos.cstcloud.cn的项目地址')
      return false;
       }*/
        if(_this.form.ifSelfStudy) {
          if(!_this.firstDomains.userName) {
            _this.messageOpen('请填写开发人员姓名', 'warning')
            return false;
          }
          if(!_this.firstDomains.userUnit) {
            _this.messageOpen('请填写开发人员单位', 'warning')
            return false;
          }
          if(!_this.firstDomains.userJob) {
            _this.messageOpen('请填写开发人员工作', 'warning')
            return false;
          }
          if(!_this.firstDomains.userPhone) {
            _this.messageOpen('请填写开发人员手机', 'warning')
            return false;
          }
          var phoneReg = /^[1][3,4,5,7,8][0-9]{9}$/;
          if(!phoneReg.test(this.firstDomains.userPhone)) {
            this.messageOpen('请填写正确手机号码', 'warning')
            return false;
          }
        }
        if(!_this.form.abstract) {
          _this.messageOpen('请填写作品摘要')
          return false;
        }
        if(!_this.ifCheckedMzs) {
          _this.messageOpen('请阅读软件投递免责协议')
          return false;
        }


        this.firstDomains = {
          activityId: this.$route.query.activityId,
          awardLevel: 0,
          awardTime: "",
          id: 0,
          joinTime: "",
          rank: 0,
          status: 0,
          softId: this.checkId,
          userId: this.userId,
          userJob: this.firstDomains.userJob,
          userName: this.firstDomains.userName,
          userPhone: this.firstDomains.userPhone,
          userUnit: this.firstDomains.userUnit,
        }
        sofoVo.userList.push(this.firstDomains);
        if(this.secondDomains.length > 0) {
          for(var i = 0; i < this.secondDomains.length; i++) {
            var cur = this.secondDomains[i]
            if(!cur.userName) {
              this.messageOpen('请填写开发人员姓名', 'warning')
              return false;
            }
            sofoVo.userList.push(cur);
          }
        }
        if(this.form.isRun === '1' && !this.form.runUrl) {
          this.messageOpen('请输入立即运行路径')
          return false;
        }
        _this.$refs[formName].validate((valid) => {
          if(valid) {
            var _this = this;
           /* this.$http.defaults.headers.common['token'] = window.SITE_CONFIG['token'] || ''*/
            _this.$http.post( '/haoweb/web/user/saveSoftInfo', sofoVo).then((response) => {
              console.log("response+++++++++++++",response)
                if(response.data.code == 0) {
                  _this.dialogDelivering = false;
                  _this.$refs[formName].resetFields();
                  _this.firstDomains.userJob = '';
                  _this.firstDomains.userName = '';
                  _this.firstDomains.userUnit = '';
                  _this.firstDomains.userPhone = '';
                  _this.secondDomains = [];
                  _this.ifCheckedMzs = false;
                  _this.form.ifShowRealName = false;
                  _this.form.ifSelfStudy = false; //是否为自研
                  if(_this.$route.path == '/personalInfo') {
                    location.reload()
                  } else {
                    this.$confirm('点击确定跳转到个人中心查看软件详情?', '提示', {
                      confirmButtonText: '确定',
                      cancelButtonText: '取消',
                      type: 'warning'
                    }).then(() => {
                      _this.toPersonalInfo()
                    })
                  }
                } else {
                  _this.$alert(response.data.msg, '提示信息', {
                    confirmButtonText: '确定',
                  });
                }


              })

          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      toLogin: function() {

      },
      //获取操作平台表单下拉内容
      getoSystemOption: function() {
        var _this = this;
        var params = new URLSearchParams();
        params.append("dictId", 6);
        this.$http.post( '/haoweb/api/dict/getDictDetailsByDictId', params)
          .then((response)=>{
            _this.operatingSystemOption = response.data.list
          })
      },
      //获取热搜词列表
      getoHotKeyWords: function() {
        var _this = this;
        var params = new URLSearchParams();
        params.append("itemType", this.searchArr.itemType);
        params.append("limit", 5);
        params.append("page", 1);
        this.$http.post( '/haoweb/web/soft/selectHotSearchList', params)
          .then((response)=>{
            console.log("hotKeyWordList=============",response)
            this.hotKeyWordList=response.data.list.records;
          })
      },
      changeHotWord:function(HotkeyWord){
        this.searchArr.keyword=HotkeyWord
        this.toSearchList()

      },
      currentSel: function(selVal) {
        if(selVal == '软件') {
          this.searchOptions.value = 1
        }
        if(selVal == '领域') {
          this.searchOptions.value = 2
        }
        if(selVal == '作者') {
          this.searchOptions.value = 3
        }

      },
      //获取报名表单下拉内容
      getListOption: function() {
        var _this = this;
        this.$http.post( '/haoweb/web/soft/softCtyAllList')
          .then((response)=>{
            var newResponse = response.data.list
            console.log("newResponse===============1111111111",newResponse)
            _this.opensourceTypeOption = newResponse[0].children; //软件类型
            _this.applicationFieldOption = newResponse[3].children; //开发领域
            _this.softCategoryOption = newResponse[1].children; //收费方式
            _this.LanguageOption = newResponse[4].children; //变成语言
            _this.userInterfaceOption = newResponse[2].children; //用户接口
            _this.openTypeOption = newResponse[5].children; //开源类型
          })
      },
      closePop: function() {
        //向父级传值
        this.dialogDelivering = false;
        /*	this.popArgument = false;
          this.$emit('listenToChild', this.popArgument)*/
      },
    }
  }
</script>
<style>
  .searchTop {
    width: 100%;
    height: 209px;
    background: #fff;
  }

  .searchTop .box-big1 .el-input__inner,
  .searchTop .box-small .el-input__inner {
    width: 400px;
  }

  .searchTop .examinedialog {
    width: 600px;
  }

  .searchTop .examinedialog .box-input {
    margin-left: 10px;
    width: 540px;
  }

  .searchTop .examinedialog .bottom .right {
    margin: 0 auto 20px;
    width: 290px;
  }

  .searchTop .examinedialog .bottom {
    overflow: hidden;
    width: 100%;
  }

  .searchTop .searchtop-box {
    width: 100%;
    height: 110px;
  }

  .searchTop .musttit {
    margin-left: 5px;
    font-size: 18px;
    font-weight: bold;
    color: #d50d24;
  }

  .searchTop .el-dialog {
    width: 700px;
  }

  .searchTop .el-dialog__body {
    padding: 5px 10px;
  }

  .searchTop .ajpsbtn {
    margin-left: 440px;
    margin-bottom: 20px;
  }

  .searchTop .searchtop-box .con {
    overflow: hidden;
    margin: 0 auto;
    width: 1200px;
  }

  .searchTop .searchtop-box .con .logo {
    float: left;
    padding: 10px 10px ;
    height: 80px;
    width: auto;
  }
  .searchTop .searchtop-box .con .hot-keyword{
    margin: 10px 0 0 400px;
    width:580px ;
    text-align: center;
  }
  .searchTop .searchtop-box .con .hot-keyword span{
    margin: 0 8px;
    color: #999;
    font-size: 12px;
    line-height: 30px;
    cursor: pointer;
  }
  .searchTop .searchtop-box .con .hot-keyword span:hover{
    color: #ea8604;
  }
  .searchTop .searchtop-box .con .search-box {
    overflow: hidden;
    float: left;
    margin: 30px 0 0 140px;
    width: 580px;
    height: 36px;
    border-radius: 5px;
    border: 1px solid #3483ff;
  }

  .searchTop .searchtop-box .con .search-box .classify {
    float: left;
    width: 100px;
    height: 36px;
    border:none;
  }
  .searchTop .searchtop-box .con .search-box .classify .el-input__inner {
    width: 120px;
    height: 36px;
    line-height: 36px;
    border: none;
  }
  .searchTop .searchtop-box .con .search-box .input {
    float: left;
    margin-left: 20px;
    width: 399px;
    height: 36px;
    background: #fff;
    border: none;
    border-left: 1px solid #999;
  }
  .searchTop .searchtop-box .con .search-box .input .el-input__inner {
    width: 340px;
    height: 36px;
    line-height: 36px;
    border: none;
  }
  .searchTop .searchtop-box .con .search-box button {
    float: left;
    width: 60px;
    height: 36px;
    background: #3285ff;
  }
  .searchTop .searchtop-box .con .search-box button i{
    font-size: 20px;
    color: #fff;
  }
  .searchTop .searchtop-box .btn {
    overflow: hidden;
    display: block;
    float: right;
    margin-top: 25px;
    padding: 0 15px 0 5px;
    width: 115px;
    height: 40px;
    font-size: 14px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 40px;
    text-align: center;
    cursor: pointer;
    background: #ec9d2f;
    border-radius: 5px;
  }
  .searchTop .searchtop-box .btn:hover{
    background: #e28504;
  }
  .searchTop .searchtop-box .btn span{
    float: left;
    display: block;
    margin: 10px 5px 0 15px;
    font-size: 20px;
    color: #fff;
  }
  .searchTop .searchtop-box .btn p{
    float: left;
    color: #fff;
  }
  .searchTop .searchtop-box .con .btn-submit{
    float: right;
    display: block;
    float: right;
    margin-top: 35px;
    padding-left: 38px;
    width: 115px;
    height: 42px;
    font-size: 14px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 42px;
    text-align: center;
    cursor: pointer;
    background:#00ff00 ;
  }
  .searchTop .header-top {
    width: 100%;
    height: 40px;
  }
  .searchTop  .menu-box{
    margin: 20px auto 10px;
    width: 1200px;
  }

  .searchTop .menu-box .classify-btn{
    position: relative;
    float: left;
    width: 200px;
    height: 48px;
    line-height: 48px;
    border-radius: 6px 6px 0 0;
    background: #3285ff;
    z-index: 10;
  }
  .searchTop .menu-box .classify-btn:hover .classify-first{
    display: block;
  }
  .searchTop  .menu-box .classify-first{
    display: none;
    position: absolute;
    top: 48px;
    width: 200px;
    height: 400px;
    background:rgba(0,0,0,0.3);
  }
  .searchTop  .menu-box .classify-first li{
    display: block;
    height: 50px;
    width: 100%;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    line-height: 50px;
    cursor: pointer;
  }
  .searchTop  .menu-box .classify-first li:hover{
    background: #5b6f84;
  }
  .searchTop  .menu-box .classify-first li:hover .classify-second{
    display: block;

  }
  .searchTop  .menu-box .classify-first li .classify-second{
    display: none;
    position: absolute;
    top:0;
    left: 200px;
    padding: 15px;
    width: 610px;
    min-height: 370px;
    background: #5b6f84;
  }
  .searchTop  .menu-box .classify-first li .classify-second dl{
    float: left;
    overflow: hidden;
    line-height: 30px;
  }
  .searchTop  .menu-box .classify-first li .classify-second dl dt{
    float: left;
    margin: 8px 0;
    padding-right: 10px;
    font-size: 14px;
    line-height: 14px;
    font-weight: normal;
    color: #2cfcfd;
    border-right: 1px solid #2cfcfd;
  }
  .searchTop  .menu-box .classify-first li .classify-second dl dd{
    float: left;
    margin-left: 10px;
  }
  .searchTop  .menu-box .classify-first li .classify-second dl dd span{
    margin-left: 5px;
    font-size: 14px;
    font-weight: normal;
    color: #fff;
  }

  .searchTop  .menu-box .classify-first li img{
    float: left;
    margin: 15px 20px 0 15px;
    width: 18px;
  }
  .searchTop  .menu-box .classify-first li span{
    float: left;
    color: #fff;
  }
  .searchTop .menu-box .classify-btn p{
    float: left;
    text-indent: 30px;
    font-size: 16px;
    color: #fff;
  }
  .searchTop .menu-box .classify-btn i{
    float: left;
    text-indent: 30px;
    line-height: 48px;
    font-size: 18px;
    color: #fff;
  }
  .searchTop .menu-box .menu-list{
    float: left;
    margin-left: 50px;
    overflow: hidden;
  }
  .searchTop .menu-box .menu-list li{
    float: left;
    padding: 0 35px;
    font-size: 16px;
    color: #666;
    line-height: 40px;
  }
  .searchTop .menu-box .menu-list .active{
    font-weight: bold;
    color: #226ad4;
  }
  .searchTop .header-top .reposbox {
    overflow: hidden;
    position: relative;
    margin: 0 auto;
    width: 1200px;
    height:40px;
    font-size: 14px;
    line-height: 40px;
    color: #fff;
  }

  .searchTop .header-top .reposbox .logo {
    float: left;
    margin: 10px 10px 0 0;
    height: 46px;
    width: auto;
  }

  .searchTop .header-top .reposbox .text {
    float: left;
    font-size: 14px;
    color: #333;
  }

  .searchTop .header-top .reposbox .right-text {
    float: right;
    margin-right: 10px;
    font-size: 14px;
    color: #333333;
    cursor: pointer;
  }

  .float-nav {
    position: fixed;
    top: 230px;
    left: 0;
    width: 60px;
    border-radius: 2px;
  }

  .float-nav li {
    width: 60px;
    height: 86px;
    border-bottom: 1px solid #a6ceec;
    background: #3c6bf7;
    cursor: pointer;
  }

  .float-nav .libg {
    background: #979899;
  }

  .float-nav li:hover {
    background: #d40303;
  }

  .float-nav li img {
    display: block;
    padding: 8px 0 3px 0;
    margin: 0px auto;
    width: 50px;
  }

  .float-nav li p {
    width: 100%;
    font-size: 12px;
    line-height: 18px;
    text-align: center;
    color: #fff;
  }

  .searchTop .singtext {
    padding: 5px 0;
    margin: 0 0 20px 50px;
    width: 600px;
    font-size: 14px;
    line-height: 20px;
    text-align: center;
    background: #d0e1f1;
  }

  .searchTop .domainsnum span {
    line-height: 40px;
    font-weight: bold;
    font-size: 14px;
    color: #F56C6C;
  }

  .searchTop .singtext .deltrbtn {
    padding: 0 5px;
    font-size: 12px;
    line-height: 14px;
    border-radius: 3px;
    height: 30px;
    line-height: 30px;
    color: #fff;
    background: #c42c12;
    cursor: pointer;
  }

  .searchTop .singtext .addtr {
    display: inline-block;
    margin: 5px 0 0 160px;
    padding: 2px 8px;
    font-size: 14px;
    height: 30px;
    line-height: 30px;
    color: #fff;
    background: #1ca141;
    border-radius: 3px;
    cursor: pointer;
  }

  .searchTop .singtext .el-input {
    padding: 5px;
    box-sizing: border-box;
  }

  .searchTop .singtext .el-input__inner {
    width: 100%;
    height: 30px;
    line-height: 30px;
  }

  .searchTop .h3 {
    width: 100%;
    line-height: 30px;
    font-size: 16px;
    color: #333;
    text-align: center;
  }

  .searchTop .feedbackdia {}

  .searchTop .feedbackdia .fbox {
    overflow: hidden;
    width: 660px;
    padding: 10px;
  }

  .searchTop .feedbackdia .borda {
    border-bottom: 1px dashed #dedede;
  }

  .searchTop .feedbackdia .fbox .demonstration {
    float: left;
    font-size: 16px;
    line-height: 30px;
    color: #666;
  }

  .searchTop .feedbackdia .fbox .el-rate {
    float: left;
    margin: 8px;
    width: 300px;
  }

  .searchTop .feedbackdia .h3 {
    width: 100%;
    font-size: 16px;
    line-height: 40px;
    text-align: left;
    font-weight: normal;
  }

  .searchTop .dialog-footer {
    display: block;
    margin: 10px auto;
    width: 200px;
  }

  .searchTop .diatit {
    padding-top: 5px;
    font-size: 12px;
    line-height: 12px;
    color: #d3d5d6;
  }
</style>
