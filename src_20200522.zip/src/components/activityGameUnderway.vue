<template>
  <div class="activityGame">
  	<!--banner-->
  	<div class="banner-top">
  		<div class="reposbox">
  			<div class="session-num">
  				2019年第一届
  			    
  			</div>
  			<div class="game-state-nostart">
  			    
  			</div>
  		    <div class="game-state">
  		    	2019年5月24日正式开启报名
  		        
  		    </div>
  		    <div class="game-time">
  		    	2019-05-23&nbsp;&nbsp;&nbsp;至&nbsp;&nbsp;&nbsp;2019-10-23
  		        
  		    </div>
  		</div>
  	    
  	</div>
  	<!--//banner-->
  	<!--con-W1200-->
  	<div class="con-W1200">
  		<!--1-->
  	  <div class="title-top title-top1">
  		<span class="span1">1</span>
  		<span class="span2">活动目的</span>
  	</div> 
  	<div class="objective">
  	    <p>     我国科研领域，长期以来依赖国外商业软件，并受制于强国，对科研信息化的发展带来较大的阻碍。开源软件的开放性特点非常符合科研领域的软件需求，对于我国的许多高校和科研机构，是一种高性价比的解决方案。
     本次活动依托“中国科技云”科研开源软件社区，将开源文化融入到科学研究中，不仅汇聚一批优秀的国产开源软件，而且逐步营造科研人才生态环境，为突破商业软件技术垄断，完善自主创新的人才培养战略，起到积极推动作用。</p>
  	</div>
  		<!--1-->
  			<!--2-->
  	  <div class="title-top title-top2">
  		<span class="span1">2</span>
  		<span class="span2">日程安排和比赛流程</span>
  	</div> 
  	<img  class="stepimg" src="../assets/activity/step_pic.png" alt="日程安排和比赛流程"/>
  		<!--2-->
  		<!--3-->
  		 <div class="title-top title-top1">
  		<span class="span1">3</span>
  		<span class="span2">参赛方式</span>
  	</div> 
  	<div class="entry-mode">
  		团队（或个人）通过网站报名。
  	    
  	</div>
  	<!--3-->
  	<!--4-->
  	 <div class="title-top title-top1">
  		<span class="span1">4</span>
  		<span class="span2">作品评审</span>
  	</div> 
  	<div class="review-top">
  	    
  	</div>
  	<div class="review-center">
  	<h4>1、参赛作品要求：</h4>	
  	<p>（1）竞赛面向科研工作者和广工高校师生，自愿报名,免费参赛。<br>
（2）作品不限行业、领域，要求具有创新性和实用性，能够填补国内领域空白，符合国家相关法律、法规以及技术规范、标准。不得抄袭、剽窃他人作品，不得侵犯第三方知识产权或其他权利。侵权的法律责任由侵权者承担。<br>
（3）所有参赛作品均须采用开放源码组织认可的开放源码许可证。软件作品和相关文档需声明知识产权归属。<br>
（4）作品必须具备可演示的用户界面（用户图形界面，Web界面或者命令行界面等）。<br>
（5）作品必须可分离原开发环境，具备可演示的运行环境，能够在组委会提供的测试账户上编译/运行或自行提供编译/运行环境。<br>
（6）作品可以使用其他开放源代码，但是必须注明出处，而且保持原来的版权。提交作品时,必须在分析设计文档中明确说明作品中各个部分的来源情况和所占比例。作品声明与其他开放源代码软件的依赖关系。<br>
（7）提交的作品应至少实现设计文档中描述的基本功能，可以正确运行，并给出正确结果。如果由于时间仓促，未能实现设计文档中描述的所有功能，应明确说明未实现的功能及其所占比例和重要程度。<br>
</P>
<h4>2、报名提交资料（所有文档都要PDF格式）：</h4>
<p>
（1）作品说明页<br>
<i></i>作品标题；<br>
<i></i>作品摘要（不超过一页）；<br>
<i></i>成员组成及联络方式。<br>
<i></i>如果是已经应用的软件作品，还需提交软件使用情况和用户意见反馈；<br>
（2）开源作品提供可执行软件包、源代码、编译安装脚本、自述文件和版权说明；<br>
</p>
<h4>3、参赛者提交报名信息后,进入初审环节。初审分析设计说明书要求：</h4>
<p>
（1） 背景和应用领域；<br>
（2） 作品特点和设计思路；<br>
（3） 运行和开发环境(可说明：是否可跨平台应用)；<br>
（4） 功能描述；<br>
（5） 工作原理；<br>
（6） 体系结构和关键技术点；<br>
（7） 功能模块设计；<br>
（8） 相关软件比较和分析；<br>
（9） 测试用例和用户手册<br>
（10） 总结。
</p>
<h4>4、初审通过后，参赛者必须按照决赛文档要求，提供相应文档，提交至决赛的参赛作品必须含有完整文档。文档纲要如下：</h4>
<p>
（1）作品必须具有创新性，实用性，设计的合理性，完整性，稳定性，安全性和可拓展性。<br>
（2）邀请专家组成评审团，按照公平、公正、公开的原则，并对团队作品完成的质量，完成时间等指标进行综合评审。<br>
（3）最终团队成绩，将在总决赛中的作品答辩环节的综合评分后得出。评出团队一，二，三等奖。<br>
  	    </p>

  	</div>
  	<div class="review-bottom">
  	    
  	</div>
  		<!--4-->
  	</div>
  		<!--con-//W1200-->
  		<div class="bottom-box">
  			<div class="bottom-box-top">
  			    
  			</div>
  			<div class="prize-box">
  				<ul>
  					<li class="li1">30000</li>
  						<li class="li2">20000</li>
  							<li class="li3">10000</li>
  							<li class="li4">3000</li>
  				</ul>
  			  <p class="prize4">
  				所有报名参与大赛未获得奖项的有效选手，均将获得参赛纪念证书，软件可以在“中国科技云”科研开源软件社区发布。
  			</p>
  			</div>
  			
  			 <p class="copy">
  				本次活动最终解释权归中科院所有
  			</p>
  			 
  		    
  		</div>
  		<!--报名浮窗-->
  		<a href="javascript:;" class="present_float">
  			<div class="ballute_blue">
  			</div>
  				<div class="ballute_pink">
  			</div>
  				<div class="ballute_red">
  			</div>
  		   <div class="present-bottom">
  		    
  		</div>
  		</a>
  			<!--报名浮窗-->
  			
  	
  			
  	
  </div>
</template>

<script>
export default {
  name: 'activityGameNoStart',
  data () {
    return {
    
      
    }
  },
   methods: {
   	
   }
}
</script>

<style>
	 .activityGame .banner-top{
	 	width: 100%;
	 	height: 636px;
	 	background:#0b54f9  url(../assets/activity/banner_top_bg.jpg) center top no-repeat;
 	
 }
 	 .activityGame .banner-top .reposbox{
 	 	position: relative;
 	 	margin: 0 auto;
 	 	width: 1200px;
 	 }
  .activityGame .banner-top .session-num{
  	position: absolute; 
  	top:230px;
  	left:352px;
  	width: 230px;
  	height: 38px;
  	font-size: 24px;
  	font-weight: bold;
  	letter-spacing: 3px;
  	color: #fff;
  	line-height: 38px;
  	text-align: center;
  	background: #55c20b;
  	
  }
  .activityGame .banner-top .game-state-nostart{
  	position: absolute; 
  	top:68px;
  	left:812px;
  	width: 382px;
  	height: 138px;
  	background: url(../assets/activity/game_state_nostart.png) no-repeat
  	
  }
  .activityGame .banner-top .game-state-start{
  	position: absolute; 
  	top:68px;
  	left:812px;
  	width: 382px;
  	height: 138px;
  	background: url(../assets/activity/game_state_start.png) no-repeat;
  	
  }
  .activityGame .banner-top .game-state-end{
  	position: absolute; 
  	top:68px;
  	left:812px;
  	width: 382px;
  	height: 138px;
  	background: url(../assets/activity/game_state_end.png) no-repeat
  	
  }
  .activityGame .banner-top .game-state {
  	position: absolute; 
  	top:180px;
  	left:952px;
  	width: 200px;
  	height: 20px;
  	line-height: 20px;
  	font-size: 14px;
  	font-weight: bold;
  	color: #de482f;
  	font-style: italic;
  }
   .activityGame .banner-top .game-time {
  	position: absolute; 
  	top:436px;
  	left:290px;
  	line-height: 40px;
  	font-size:18px;
  	font-weight: bold;
  	color: #fff;
  	letter-spacing: 1px;
  }
  .activityGame .title-top{
  	overflow: hidden;
  	margin: 50px 0  30px 0;
  	width: 100%;
  	height: 33px;
  	line-height: 33px;
  	font-weight: bold;
  	color: #fff;
  }
    .activityGame .title-top1{
  	background: url(../assets/activity/title_bg.png) left top no-repeat;
  }
   .activityGame .title-top2{
  	background: url(../assets/activity/title_bg_long.png)  left top no-repeat;
  }
    .activityGame .title-top .span1{
    	float: left;
    	margin-left: 21px;
    	display: inline-block;
    	width: 26px;
    	font-size: 20px;
    	text-align: center;
    	color: #006af5;
    	
    }
     .activityGame .title-top .span2{
     	float: left;
     		display: inline-block;
     		margin: 0 0 0 10px;
    	font-size: 16px;
    	color: #fff; 
    	line-height: 32px; 	
    }
 	.activityGame .objective{
 		margin-bottom: 50px;
 		width: 1200px;
 		height: 246px;
 		background: url(../assets/activity/text_bg.png) no-repeat;
 	}
 	.activityGame .objective p{
 		padding:80px 30px 0;
 		font-size: 16px;
 		line-height: 28px;
 		text-indent: 22px;
 		color: #666;
 	}
 	.activityGame .stepimg{
 		margin-top:30px;
 		width: 1200px;
 		height: 195px;
 	}
 	.activityGame .entry-mode{
 		padding:10px 20px;
 		width: 1160px;
 		line-height: 36px;
 		background: #ededed;
 	}
 	.activityGame .review-top{
 		width: 1200px;
 		height: 47px;
 		background: url(../assets/activity/review_bg_top.jpg) no-repeat;
 	}
 	.activityGame .review-bottom{
 		width: 1200px;
 		height: 44px;
 		background: url(../assets/activity/review_bg_bottom.jpg) no-repeat;
 	}
 		.activityGame .review-center{
 			padding: 0px 30px;
 			width: 1140px;
 			background: url(../assets/activity/review_bg_center.jpg) repeat-y;
 		}
 		.activityGame .review-center h4{
 			display: inline-block;
 			margin: 20px 0 10px;
 			padding: 2px 10px;
 			font-size: 18px;
 			color: #fff ;
 			line-height: 30px;
 			background: #f2bc18;
 		}
 		.activityGame .review-center p{
 			font-size: 16px;
 			line-height: 26px;
 			color: #666;
 		
 		}
 		.activityGame .review-center p i{
 			display: inline-block;
 			margin-right: 5px;
 			width: 10px;
 			height: 10px;
 			border-radius: 50%;
 			background: #c72d08;
 		}
 		.activityGame .bottom-box{
 			width: 100%;
 			height: 700px;
 			background: #095cfc;
 		}
 		.activityGame .bottom-box .bottom-box-top{
 			width: 100%;
 			height: 104px;
 			background: url(../assets/activity/bottom_top_bg.png) repeat-x;
 		}
 		.activityGame .bottom-box .prize-box{
 			position: relative;
 			margin: 50px auto 0;
 			overflow: hidden;
 			width:1200px ;
 			height: 443px;
 			background: url(../assets/activity/Prize_bg.png) no-repeat;
 		}
 		.activityGame .bottom-box .copy{
 			margin: 10px auto;
 			width: 1200px;
 			text-align: right;
 			font-size: 14px;
 			line-height: 20px;
 			color: #dcdee6;
 		}
 		.activityGame .bottom-box .prize-box ul{
 			overflow: hidden;
 			margin: 130px 10px 0 30px;
 		}
 		.activityGame .bottom-box .prize-box ul li{
 			margin-left:80px;
 			padding: 138px 0 42px 0;
 			float: left;
 			width: 183px;
 			height: 212px;
 			height: 36px;
 			font-size: 32px;
 			color: #fff;
 			font-weight: bold;
 			line-height: 36px;
 			text-align: center;
 			text-indent: 16px;
 		}
 		.activityGame .bottom-box .prize-box ul .li1{
 			background: url(../assets/activity/Prize_1.png) no-repeat;
 		}
 			.activityGame .bottom-box .prize-box ul .li2{
 			background: url(../assets/activity/Prize_2.png) no-repeat;
 		}
 			.activityGame .bottom-box .prize-box ul .li3{
 			background: url(../assets/activity/Prize_3.png) no-repeat;
 		}
 			.activityGame .bottom-box .prize-box ul .li4{
 			background: url(../assets/activity/Prize_4.png) no-repeat;
 		}
 		.activityGame .bottom-box .prize-box .prize4{
 			position: absolute;
 			left: 355px;
 			top: 375px;
 			width: 500px;
 			font-size: 16px;
 			line-height: 26px;
 			color: #fff;
 		}
 		.present_float{
 			display: block;
 			position: fixed;
 			right: 10px;
 			top: 260px;
 			width: 180px;
 			z-index: 10000;
 		}
 		.present_float .present-bottom{
 			position: relative;
 			margin-top: 150px;
 			width: 148px;
 			height: 111px;
 			background: url(../assets/activity/present_float.png) no-repeat;
 			z-index: 10005;
 		}
 		.present_float .ballute_box{
 			position: relative;
 			width: 420px;
 			height: 370px;
 				
 			}
 		.present_float .ballute_blue{
 			position: absolute;
 			right: 20px;
 			top: 40px;
 			width: 59px;
 			height: 165px;
 			background: url(../assets/activity/ballute_blue.png) no-repeat;
 				 animation: ballute_pink 4.5s linear 0s infinite;
    	-webkit-animation: ballute_pink 4.5s linear 0s infinite;
    	-webkit-animation-fill-mode: both;
    	animation-fill-mode: both;
 		}
 		.present_float .ballute_pink{
 			position: absolute;
 			left: 26px;
 			top: 60px;
 			width: 51px;
 			height: 111px;
 			background: url(../assets/activity/ballute_pink.png) no-repeat;
 			 animation: ballute_pink 4s linear 0s infinite;
    	-webkit-animation: ballute_pink 4s linear 0s infinite;
    	-webkit-animation-fill-mode: both;
    	animation-fill-mode: both;
 			
 		}
 		.present_float .ballute_red{
 			position: absolute;
 			left: 5px;
 			top: 10px;
 			width: 56px;
 			height: 165px;
 			background: url(../assets/activity/ballute_red.png) no-repeat;
 			 animation: ballute_pink 5s linear 0s infinite;
    	-webkit-animation: ballute_pink 5s linear 0s infinite;
    	-webkit-animation-fill-mode: both;
    	animation-fill-mode: both;
 		}
 		
@keyframes ballute_pink {
    0% {
        transform: rotate(10deg);
        transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
    25% {
        transform:rotate(0deg);
          transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
     50%{
    	transform:rotate(-10deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
   75%{
    	transform:rotate(0deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
     100%{
    	transform:rotate(10deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
}

@-webkit-keyframes ballute_pink {
 0% {
        transform: rotate(10deg);
        transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
    25% {
        transform:rotate(0deg);
          transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
     50%{
    	transform:rotate(-10deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
   75%{
    	transform:rotate(0deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
     100%{
    	transform:rotate(10deg);
    	  transform-origin:100% 100%;/*定义动画的旋转中心点*/
    }
}


</style>
